# CAAC Security English

中国民航安全员英语训练工具 V1。

功能：课程分类、专业词汇、标准表达、情景训练、搜索、英文语音朗读、本地学习进度。

部署：上传整个目录到 GitHub 仓库 → Settings → Pages → Deploy from branch → main/root。

说明：内容为英语训练示例，不替代任何现行民航法规、规章、公司SOP或执勤指令。涉及具体执法/处置时，应以现行规定和单位程序为准。
